<?php
class TeastCaseConstants
{
    /**
     * fundoApi constants
     */
    public $loginTestcaseUrl = "http://localhost/codeigniter/login";
    public $loginTestcaseFileName = "loginTestCase.json";
    public $registrationTestcaseUrl =   "http://localhost/codeigniter/registration";
    public $registrationTestcaseFileName = "registrationTestCase.json";
    public $forgorTestcaseUrl =   "http://localhost/codeigniter/forgotPassword";
    public $forgotTestcaseFileName = "forgotTestCase.json";
    /**
     * notes constants
     */
    public $notesTestcaseUrl =   "http://localhost/codeigniter/forgotPassword";
    public $notesTestcaseFileName = "notesTestCase.json";
}
