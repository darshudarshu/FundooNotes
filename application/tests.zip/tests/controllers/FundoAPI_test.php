<?php
require_once "/var/www/html/codeigniter/application/controllers/FundoAPI.php";
include "/var/www/html/codeigniter/application/tests/controllers/TeastCaseConstants.php";
class FundoAPI_test extends TestCase
{
    /**
     * variable to the constants
     */
    public $constantClassObj = null;
    public function __construct()
    {
        $this->constantClassObj = new TeastCaseConstants();
    }

    public function testlogin()
    {

        $url                  = $this->constantClassObj->loginTestcaseUrl;
        $file                 = $this->constantClassObj->loginTestcaseFileName;
        $data                 = file_get_contents($file, true);
        $testCaseExampleArray = json_decode($data, true);

        foreach ($testCaseExampleArray as $key => $value) {

            $ch       = curl_init($url);
            $email    = $value['testEmail'];
            $password = $value['password'];
            curl_setopt($ch, CURLOPT_POSTFIELDS, "email=$email&password=$password");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);
            curl_close($ch);
            $res = json_decode($result);
            $this->assertEquals($value['expected'], $res->message);
        }
    }

    public function testRegistration()
    {
        $url                  = $this->constantClassObj->registrationTestcaseUrl;
        $file                 = $this->constantClassObj->registrationTestcaseFileName;
        $data                 = file_get_contents($file, true);
        $testCaseExampleArray = json_decode($data, true);
        foreach ($testCaseExampleArray as $key => $value) {
            $email        = $value['email'];
            $password     = $value['password'];
            $username     = $value['username'];
            $mobilenumber = $value['mobilenumber'];
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "username=$username&email=$email&mobilenumber=$mobilenumber&password=$password");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);
            curl_close($ch);
            $res = json_decode($result);
            $this->assertEquals($value['expected'], $res->message);
        }

    }
    public function testforgotPassword()
    {
        $url                  = $this->constantClassObj->forgorTestcaseUrl;
        $file                 = $this->constantClassObj->forgotTestcaseFileName;
        $data                 = file_get_contents($file, true);
        $testCaseExampleArray = json_decode($data, true);
        foreach ($testCaseExampleArray as $key => $value) {
            $email        = $value['email'];
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "email=$email");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);
            curl_close($ch);
            $res = json_decode($result);
            $this->assertEquals($value['expected'], $res->message);
        }

    }
}
