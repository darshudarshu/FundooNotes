<?php
require_once "/var/www/html/codeigniter/application/controllers/FundoAPI.php";
include "/var/www/html/codeigniter/application/tests/controllers/TeastCaseConstants.php";
class NotesController_test extends TestCase
{
    /**
     * variable to the constants
     */
    public $constantClassObj = null;
    public function __construct()
    {
        $this->constantClassObj = new TeastCaseConstants();
    }
}