<?php
\Cloudinary::config(array(
    "cloud_name" => "dgjjle6qi",
    "api_key"    => "386537768216348",
    "api_secret" => "4v42g11VTPZgAuabpHCzjQhYDv0",
));
